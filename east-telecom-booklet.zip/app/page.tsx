import { BrochureNav } from "@/components/brochure/brochure-nav"
import { HeroSection } from "@/components/brochure/hero-section"
import { AdvantagesSection } from "@/components/brochure/advantages-section"
import { SmsSection } from "@/components/brochure/sms-section"
import { DatacenterSection } from "@/components/brochure/datacenter-section"
import { XSolutionSection } from "@/components/brochure/xsolution-section"
import { AudienceSection } from "@/components/brochure/audience-section"
import { CtaSection } from "@/components/brochure/cta-section"

export default function BrochurePage() {
  return (
    <main className="min-h-screen bg-background">
      <BrochureNav />

      {/* Hero */}
      <HeroSection />

      {/* Advantages */}
      <div id="advantages">
        <AdvantagesSection />
      </div>

      {/* SMS Platform */}
      <div id="sms">
        <SmsSection />
      </div>

      {/* Data Center */}
      <div id="datacenter">
        <DatacenterSection />
      </div>

      {/* X Solution */}
      <div id="xsolution">
        <XSolutionSection />
      </div>

      {/* Audience & Results */}
      <div id="audience">
        <AudienceSection />
      </div>

      {/* CTA & Contacts */}
      <div id="cta">
        <CtaSection />
      </div>
    </main>
  )
}
