import {
  Building2,
  Landmark,
  CreditCard,
  ShoppingBag,
  Rocket,
  Building,
} from "lucide-react"

const audiences = [
  { icon: Landmark, name: "Банки", description: "Надёжная инфраструктура для банковских систем" },
  { icon: CreditCard, name: "Финтех", description: "Масштабируемые решения для финтех-компаний" },
  { icon: Building2, name: "МФО", description: "SMS и облачные сервисы для микрофинансов" },
  { icon: ShoppingBag, name: "E-commerce", description: "Платформа для интернет-торговли" },
  { icon: Rocket, name: "Стартапы", description: "Гибкие тарифы для растущих компаний" },
  { icon: Building, name: "Корпорации", description: "Комплексные решения для крупного бизнеса" },
]

const results = [
  "Надёжные коммуникации",
  "Контролируемые расходы",
  "Быстрое масштабирование",
  "Соответствие требованиям регуляторов",
  "Локальный технологический партнёр",
]

export function AudienceSection() {
  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="max-w-6xl mx-auto px-6">
        {/* Who it's for */}
        <div className="mb-20">
          <span className="text-primary font-mono text-sm font-medium tracking-widest uppercase mb-3 block">
            {"Для кого"}
          </span>
          <h2 className="text-3xl md:text-5xl font-mono font-bold text-foreground leading-tight text-balance mb-12">
            {"Наши клиенты"}
          </h2>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {audiences.map((a) => (
              <div
                key={a.name}
                className="group flex flex-col items-center text-center p-6 rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-300"
              >
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <a.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-foreground font-semibold text-sm mb-1">{a.name}</h3>
                <p className="text-muted-foreground text-xs leading-relaxed">{a.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Results */}
        <div className="rounded-2xl bg-card border border-primary/20 p-8 md:p-12">
          <span className="text-primary font-mono text-sm font-medium tracking-widest uppercase mb-3 block">
            {"Результат"}
          </span>
          <h3 className="text-2xl md:text-3xl font-mono font-bold text-foreground mb-8">
            {"Что получает бизнес"}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {results.map((r, i) => (
              <div
                key={r}
                className="flex items-center gap-4 p-4 rounded-xl bg-secondary"
              >
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <span className="text-primary font-mono text-sm font-bold">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </div>
                <span className="text-foreground text-sm font-medium">{r}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
