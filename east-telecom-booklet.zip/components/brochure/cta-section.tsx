import { Mail, Phone, MapPin, Globe } from "lucide-react"

export function CtaSection() {
  return (
    <section className="py-20 md:py-28 bg-secondary">
      <div className="max-w-6xl mx-auto px-6">
        <div className="rounded-2xl bg-card border border-primary/20 p-8 md:p-16 text-center">
          {/* Logo */}
          <div className="inline-flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-lg bg-foreground flex items-center justify-center">
              <span className="text-background font-mono font-bold text-xl">ET</span>
            </div>
            <span className="text-foreground font-mono text-2xl font-bold tracking-tight">
              East <span className="text-primary">Telecom</span>
            </span>
          </div>

          <h2 className="text-3xl md:text-5xl font-mono font-bold text-foreground leading-tight text-balance mb-5">
            {"Готовы обсудить ваш кейс?"}
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto leading-relaxed mb-10">
            {"Мы предложим оптимальное решение под задачи вашего бизнеса. Свяжитесь с нами для консультации."}
          </p>

          {/* Contact info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-3xl mx-auto">
            <a
              href="tel:+998781500000"
              className="flex items-center justify-center gap-3 p-4 rounded-xl bg-secondary border border-border hover:border-primary/30 transition-all text-foreground"
            >
              <Phone className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">+998 78 150 00 00</span>
            </a>
            <a
              href="mailto:ask@etc.uz"
              className="flex items-center justify-center gap-3 p-4 rounded-xl bg-secondary border border-border hover:border-primary/30 transition-all text-foreground"
            >
              <Mail className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">ask@etc.uz</span>
            </a>
            <a
              href="https://etc.uz"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 p-4 rounded-xl bg-secondary border border-border hover:border-primary/30 transition-all text-foreground"
            >
              <Globe className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">etc.uz</span>
            </a>
            <div className="flex items-center justify-center gap-3 p-4 rounded-xl bg-secondary border border-border text-foreground">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-foreground">{"Ташкент"}</span>
            </div>
          </div>

          {/* CTA Button */}
          <div className="mt-10">
            <a
              href="mailto:ask@etc.uz"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-foreground text-background font-mono font-bold text-base hover:bg-primary hover:text-primary-foreground transition-colors"
            >
              {"Связаться с нами"}
              <Mail className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-10 text-center">
          <p className="text-muted-foreground text-xs">
            {"© 2003–2026 JV LLC East Telecom. Ташкент, Узбекистан."}
          </p>
        </div>
      </div>
    </section>
  )
}
