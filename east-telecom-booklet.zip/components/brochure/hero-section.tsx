"use client"

import { ArrowDown } from "lucide-react"
import Image from "next/image"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero-datacenter.jpg"
          alt="East Telecom дата-центр"
          fill
          className="object-cover opacity-15"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/90 via-background/70 to-background" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        {/* Logo */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-lg bg-foreground flex items-center justify-center">
              <span className="text-background font-mono font-bold text-xl">ET</span>
            </div>
            <span className="text-foreground font-mono text-2xl font-bold tracking-tight">
              East <span className="text-primary">Telecom</span>
            </span>
          </div>
        </div>

        {/* Main headline */}
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-mono font-bold text-foreground leading-tight text-balance mb-6">
          {"Единая ICT-экосистема"}
          <br />
          <span className="text-primary">{"для бизнеса"}</span>
        </h1>

        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed mb-4">
          {"Технологический партнёр для компаний, которым важны стабильность, безопасность и масштабирование"}
        </p>

        {/* Service tags */}
        <div className="flex flex-wrap justify-center gap-3 mt-8 mb-12">
          {["SMS Platform", "Data Center", "X Solution"].map((tag) => (
            <span
              key={tag}
              className="px-5 py-2.5 rounded-full border border-foreground/20 bg-foreground text-background font-mono text-sm font-medium tracking-wide"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 mt-12 max-w-3xl mx-auto">
          {[
            { value: "100+", label: "населённых пунктов" },
            { value: "6 000+", label: "бизнес-клиентов" },
            { value: "2 600 км", label: "цифровая сеть" },
            { value: "700+", label: "специалистов" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-3xl md:text-4xl font-mono font-bold text-primary mb-1">
                {stat.value}
              </div>
              <div className="text-xs md:text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll hint */}
      <button
        onClick={() => window.scrollTo({ top: window.innerHeight, behavior: "smooth" })}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce text-muted-foreground hover:text-primary transition-colors"
        aria-label="Прокрутить вниз"
      >
        <ArrowDown className="w-6 h-6" />
      </button>
    </section>
  )
}
