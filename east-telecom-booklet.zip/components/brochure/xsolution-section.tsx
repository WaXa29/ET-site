import Image from "next/image"
import {
  Search,
  FileText,
  Layers,
  KeyRound,
  Truck,
  ScrollText,
  BadgeCheck,
  Wrench,
  Check,
} from "lucide-react"

const services = [
  { icon: Search, text: "Обследование инфраструктуры" },
  { icon: FileText, text: "Помощь в создании ТЗ" },
  { icon: Layers, text: "Проектирование архитектуры" },
  { icon: KeyRound, text: 'Реализация "под ключ"' },
  { icon: Truck, text: "Поставка оборудования" },
  { icon: ScrollText, text: "Лицензии Microsoft и других вендоров" },
  { icon: BadgeCheck, text: "Гарантия и официальная лицензия" },
  { icon: Wrench, text: "Техническая поддержка" },
]

const formats = [
  "Только оборудование",
  "Только установка",
  "Только консультация",
  "Полный проект под ключ",
]

export function XSolutionSection() {
  return (
    <section className="py-20 md:py-28 bg-secondary">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-16">
          <div>
            <span className="text-primary font-mono text-sm font-medium tracking-widest uppercase mb-3 block">
              {"X Solution"}
            </span>
            <h2 className="text-3xl md:text-5xl font-mono font-bold text-foreground leading-tight text-balance mb-5">
              {"Комплексные B2B ICT-решения"}
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed">
              {"Мы закрываем весь цикл проекта — от идеи до эксплуатации. Договорённости с вендорами и крупными поставщиками."}
            </p>
          </div>

          {/* Image */}
          <div className="relative rounded-2xl overflow-hidden aspect-[4/3]">
            <Image
              src="/images/b2b-solutions.jpg"
              alt="B2B ICT решения East Telecom"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-secondary/60 to-transparent" />
          </div>
        </div>

        {/* Services grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
          {services.map((s) => (
            <div
              key={s.text}
              className="flex items-start gap-3 p-5 rounded-xl bg-card border border-border"
            >
              <s.icon className="w-5 h-5 text-primary shrink-0 mt-0.5" />
              <span className="text-foreground text-sm leading-relaxed">{s.text}</span>
            </div>
          ))}
        </div>

        {/* Flexible formats */}
        <div className="rounded-2xl bg-card border border-border p-8 md:p-12">
          <h3 className="text-2xl md:text-3xl font-mono font-bold text-foreground mb-2">
            {"Гибкий формат работы"}
          </h3>
          <p className="text-muted-foreground mb-8">
            {"Можно заказать любую часть проекта отдельно или получить комплексное решение"}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {formats.map((f, i) => (
              <div
                key={f}
                className={`flex items-center gap-3 p-5 rounded-xl border transition-all ${
                  i === formats.length - 1
                    ? "bg-primary/10 border-primary/30"
                    : "bg-secondary border-border"
                }`}
              >
                <Check
                  className={`w-5 h-5 shrink-0 ${
                    i === formats.length - 1 ? "text-primary" : "text-muted-foreground"
                  }`}
                />
                <span
                  className={`text-sm font-medium ${
                    i === formats.length - 1 ? "text-primary" : "text-foreground"
                  }`}
                >
                  {f}
                </span>
              </div>
            ))}
          </div>

          <p className="text-primary font-mono text-sm font-medium mt-8 tracking-wide">
            {"Один партнёр — единая ответственность"}
          </p>
        </div>
      </div>
    </section>
  )
}
