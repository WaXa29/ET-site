import Image from "next/image"
import {
  CheckCircle2,
  MessageSquare,
  BarChart3,
  Plug,
  ShieldCheck,
  Rocket,
} from "lucide-react"

const features = [
  { icon: CheckCircle2, text: "Высокая доставляемость по всем операторам" },
  { icon: Plug, text: "Прямые маршруты без посредников" },
  { icon: MessageSquare, text: "API / SMPP интеграция" },
  { icon: BarChart3, text: "Статусы доставки и аналитика" },
  { icon: Rocket, text: "Масштабирование под рост трафика" },
  { icon: ShieldCheck, text: "Поддержка высоконагруженных сервисов" },
]

const filterSteps = [
  {
    step: "01",
    title: "Блокировка",
    description: "Блокировка нешаблонных сообщений на нашей стороне",
  },
  {
    step: "02",
    title: "Регистрация",
    description: "Регистрация сообщений через бота автоматически",
  },
  {
    step: "03",
    title: "Преобразование",
    description: "Автоматическое преобразование в шаблон",
  },
  {
    step: "04",
    title: "Отправка",
    description: "Отправка итогового SMS получателю",
  },
]

export function SmsSection() {
  return (
    <section className="py-20 md:py-28 bg-secondary">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-20">
          <div>
            <span className="text-primary font-mono text-sm font-medium tracking-widest uppercase mb-3 block">
              {"SMS Platform"}
            </span>
            <h2 className="text-3xl md:text-5xl font-mono font-bold text-foreground leading-tight text-balance mb-5">
              {"Надёжная A2P SMS платформа"}
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-8">
              {"Платформа для OTP, транзакционных и сервисных SMS с прямыми маршрутами ко всем операторам Узбекистана"}
            </p>

            {/* Features list */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {features.map((f) => (
                <div key={f.text} className="flex items-start gap-3">
                  <f.icon className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-foreground text-sm leading-relaxed">{f.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Image */}
          <div className="relative rounded-2xl overflow-hidden aspect-[4/3]">
            <Image
              src="/images/sms-platform.jpg"
              alt="SMS Platform визуализация"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-secondary/60 to-transparent" />
          </div>
        </div>

        {/* Smart filter feature */}
        <div className="rounded-2xl bg-card border border-border p-8 md:p-12">
          <div className="max-w-2xl mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-mono font-medium mb-4">
              <ShieldCheck className="w-3.5 h-3.5" />
              {"Уникальная фишка"}
            </div>
            <h3 className="text-2xl md:text-3xl font-mono font-bold text-foreground mb-3">
              {"Интеллектуальная фильтрация SMS"}
            </h3>
            <p className="text-muted-foreground leading-relaxed">
              {"Мы можем на своей стороне автоматически обрабатывать, фильтровать и преобразовывать SMS — клиент платит только за шаблонные сообщения"}
            </p>
          </div>

          {/* Steps */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
            {filterSteps.map((s) => (
              <div key={s.step} className="relative">
                <span className="text-primary/20 font-mono text-5xl font-bold absolute -top-2 -left-1">
                  {s.step}
                </span>
                <div className="relative pt-10">
                  <h4 className="text-foreground font-semibold mb-1">{s.title}</h4>
                  <p className="text-muted-foreground text-sm leading-relaxed">{s.description}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Benefit badges */}
          <div className="flex flex-wrap gap-3">
            {[
              "Оплата только за шаблонные SMS",
              "Нет переплаты за нешаблонные",
              "Снижение расходов на трафик",
              "Контроль качества",
            ].map((badge) => (
              <span
                key={badge}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium"
              >
                <CheckCircle2 className="w-4 h-4" />
                {badge}
              </span>
            ))}
          </div>

          <p className="text-muted-foreground text-sm mt-6 italic">
            {"Особенно выгодно для банков, МФО и финтех-платформ"}
          </p>
        </div>
      </div>
    </section>
  )
}
