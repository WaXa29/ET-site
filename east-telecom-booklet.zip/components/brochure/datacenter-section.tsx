import Image from "next/image"
import {
  Cloud,
  Database,
  MapPin,
  Timer,
  ShieldCheck,
  RefreshCw,
  ArrowUpRight,
} from "lucide-react"

const capabilities = [
  {
    icon: Cloud,
    title: "Cloud IDC",
    description: "Облачная инфраструктура и размещение оборудования в нашем дата-центре",
  },
  {
    icon: MapPin,
    title: "Данные в Узбекистане",
    description: "Все данные хранятся локально, в соответствии с требованиями регуляторов",
  },
  {
    icon: Timer,
    title: "Минимальные задержки",
    description: "Стабильный доступ с минимальной латентностью внутри страны",
  },
  {
    icon: ShieldCheck,
    title: "Безопасность",
    description: "Высокий уровень физической и сетевой безопасности инфраструктуры",
  },
  {
    icon: RefreshCw,
    title: "Резервирование",
    description: "Отказоустойчивость и резервное копирование на уровне инфраструктуры",
  },
  {
    icon: ArrowUpRight,
    title: "Масштабирование",
    description: "Рост ресурсов без остановки работающих сервисов",
  },
]

const useCases = [
  "Банковские системы",
  "Финтех-платформы",
  "CRM / ERP",
  "Высоконагруженные приложения",
]

export function DatacenterSection() {
  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header with image */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-16">
          {/* Image */}
          <div className="relative rounded-2xl overflow-hidden aspect-[4/3] order-2 lg:order-1">
            <Image
              src="/images/cloud-infrastructure.jpg"
              alt="Облачная инфраструктура East Telecom"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
          </div>

          {/* Text */}
          <div className="order-1 lg:order-2">
            <span className="text-primary font-mono text-sm font-medium tracking-widest uppercase mb-3 block">
              {"Data Center"}
            </span>
            <h2 className="text-3xl md:text-5xl font-mono font-bold text-foreground leading-tight text-balance mb-5">
              {"Cloud & Colocation"}
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-8">
              {"Локальная инфраструктура для хранения и обработки данных. Ваши серверы — в надёжном и безопасном месте."}
            </p>

            {/* Use cases */}
            <div className="flex flex-wrap gap-2">
              {useCases.map((uc) => (
                <span
                  key={uc}
                  className="px-4 py-2 rounded-full border border-border text-foreground text-sm font-medium"
                >
                  {uc}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Capabilities grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {capabilities.map((cap) => (
            <div
              key={cap.title}
              className="group p-6 rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-300"
            >
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                  <cap.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="text-foreground font-semibold text-base mb-1">{cap.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{cap.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Highlight badge */}
        <div className="mt-10 flex items-center justify-center">
          <div className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-card border border-border">
            <Database className="w-4 h-4 text-primary" />
            <span className="text-foreground text-sm font-medium">
              {"Подходит для банковских систем, финтеха, CRM, ERP и высоконагруженных платформ"}
            </span>
          </div>
        </div>
      </div>
    </section>
  )
}
