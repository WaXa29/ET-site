import {
  Shield,
  Zap,
  Globe,
  HeadphonesIcon,
  TrendingUp,
  Clock,
  BadgeCheck,
  Server,
} from "lucide-react"

const advantages = [
  {
    icon: Server,
    title: "Собственная инфраструктура",
    description: "Телеком- и дата-центр инфраструктура полностью принадлежит нам",
  },
  {
    icon: Globe,
    title: "Прямые подключения",
    description: "Ко всем операторам Узбекистана без посредников",
  },
  {
    icon: Shield,
    title: "Отказоустойчивость",
    description: "Высокий SLA для критичных сервисов вашего бизнеса",
  },
  {
    icon: HeadphonesIcon,
    title: "Локальная поддержка",
    description: "Быстрые интеграции и поддержка на местном уровне",
  },
  {
    icon: TrendingUp,
    title: "Гибкие тарифы",
    description: "Тарифы под реальные объёмы вашего бизнеса",
  },
  {
    icon: Zap,
    title: "Минимальные задержки",
    description: "Низкая латентность внутри страны благодаря локальной сети",
  },
  {
    icon: BadgeCheck,
    title: "Прозрачная стоимость",
    description: "Без валютных рисков и скрытых платежей",
  },
  {
    icon: Clock,
    title: "Соответствие регуляциям",
    description: "Полное соответствие локальным требованиям и стандартам",
  },
]

export function AdvantagesSection() {
  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section header */}
        <div className="max-w-2xl mb-16">
          <span className="text-primary font-mono text-sm font-medium tracking-widest uppercase mb-3 block">
            {"Почему East Telecom"}
          </span>
          <h2 className="text-3xl md:text-5xl font-mono font-bold text-foreground leading-tight text-balance mb-5">
            {"Локальный ICT-оператор с собственной инфраструктурой"}
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            {"Работаем с банками, финтехом и крупными корпоративными клиентами с 2003 года"}
          </p>
        </div>

        {/* Advantages grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {advantages.map((adv) => (
            <div
              key={adv.title}
              className="group p-6 rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-300"
            >
              <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <adv.icon className="w-5 h-5 text-primary" />
              </div>
              <h3 className="text-foreground font-semibold text-base mb-2">{adv.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{adv.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
